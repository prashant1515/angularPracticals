import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SecondComponent } from './second/second.component';
import {FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { FilmComponent } from './film/film.component';
import { StarRatingPipe } from './pipes/star-rating.pipe';
import { FilmsearchComponent } from './filmsearch/filmsearch.component';

@NgModule({
  declarations: [
    AppComponent,
    SecondComponent,
    LoginComponent,
    FilmComponent,
    StarRatingPipe,
    FilmsearchComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
