import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-filmsearch',
  templateUrl: './filmsearch.component.html',
  styleUrls: ['./filmsearch.component.css']
})
export class FilmsearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  showFilms:boolean=false;

  
  @Input() films: any;
  @Input() loggedIn:any;
  v:string="";



  searchFilms(val:string){
    this.showFilms=true;
    this.v=val;
    

  }
}
