import { Component, OnInit } from '@angular/core';
import  {NgForm} from '@angular/forms';
import { NavigationEnd, Router, ɵROUTER_PROVIDERS } from '@angular/router';
import { LoginRequest } from '../models/authentication/login-request';
import { StarRatingPipe } from '../pipes/star-rating.pipe';
import {ShareDataService} from '../share-data.service';
import { AuthenticationService } from '../authentication.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [ StarRatingPipe ]
})
export class LoginComponent implements OnInit {

  constructor(private starRating:StarRatingPipe,private routerr:Router,private share:ShareDataService,private authenticationService:AuthenticationService) { }
  
  ngOnInit(): void {
  }

  email:any;
  password:any;
  loggedIn:boolean=false;
  onSubmitForm(form:NgForm){
    this.loggedIn=true;

    this.navigatePostLogin();
    console.log(form.value)
    this.share.sharedata=this.loggedIn;
    this.login();
     }


     

      // metascore:number=2;
      // rating=this.starRating.transform(this.films[]);

      



navigatePostLogin(): void {
this.routerr.navigateByUrl('/filmSearch');
}




login(): void {
  this.authenticationService.login(this.loginRequest)
    .subscribe(response => {
      this.authenticationService.token = response.token;
      //const returnUrl = this.routerr.snapshot.paramMap.get('returnUrl')
      this.routerr.navigateByUrl("/filmSearch")
    }
    
    
    )
}

register(): void {
  this.authenticationService.register(this.loginRequest)
    .subscribe(response => {})
}

get loginRequest(): LoginRequest {
  return new LoginRequest(this.email, this.password)
}






}