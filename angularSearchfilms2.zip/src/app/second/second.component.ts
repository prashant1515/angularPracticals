import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {

  constructor() { }
  name:string="prashant";

  
  ghost1={name:"ihdf"};

  temperature:number=20;
  fun1(){
        console.log("fun1 called");
  }
  ngOnInit(): void {
  }


  @Input() subject:string="";
}
