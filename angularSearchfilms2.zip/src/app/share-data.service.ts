import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {
    sharedata: boolean = false;
  constructor(private routerr:Router) { }


  loggedOut(data:boolean){
    this.sharedata=data;
    this.routerr.navigateByUrl("/login");
  }
  token: string | null = null

get loggedIn(): boolean {
  return this.token != null
}
}


