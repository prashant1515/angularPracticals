import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FilmComponent } from './film/film.component';
import { FilmsearchComponent } from './filmsearch/filmsearch.component';
import { LoginComponent } from './login/login.component';
import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [

  {path:'login',component:LoginComponent},
  {path:'filmSearch',component:FilmsearchComponent},
  {path:'',pathMatch:'full',redirectTo:'/login'},
  {path:'**',component:NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
