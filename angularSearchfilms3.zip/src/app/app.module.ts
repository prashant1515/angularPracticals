import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SecondComponent } from './second/second.component';
import {FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { FilmComponent } from './film/film.component';
import { StarRatingPipe } from './pipes/star-rating.pipe';
import { FilmsearchComponent } from './filmsearch/filmsearch.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    SecondComponent,
    LoginComponent,
    FilmComponent,
    StarRatingPipe,
    FilmsearchComponent,
    NotFoundComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
