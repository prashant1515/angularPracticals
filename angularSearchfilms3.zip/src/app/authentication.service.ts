import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginRequest } from './models/authentication/login-request';
import { RegistrationRequest } from './models/authentication/registration-request';
import { UserResponse } from './models/authentication/user-response';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private baseUrl = 'api/user'

constructor(private httpClient: HttpClient) {}

login(loginRequest: LoginRequest): Observable<UserResponse> {
  console.log("return");
  return this.httpClient.post<UserResponse>(this.baseUrl + '/login', loginRequest)

  
}

register(loginRequest: LoginRequest): Observable<UserResponse> {
  const registrationRequest = new RegistrationRequest(
    loginRequest.email,
    loginRequest.password,
    'John',
    'Smith'
  )
  return this.httpClient.post<UserResponse>(this.baseUrl + '/register', registrationRequest)
}


token: string | null = null;

get loggedIn(): boolean {
  return this.token != null;
}}
